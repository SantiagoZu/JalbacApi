﻿using JalbacApi.Models;

namespace JalbacApi.Repositorio.IRepositorio
{
    public interface IRolRepositorio : IRepositorio<Rol>
    {
    }
}

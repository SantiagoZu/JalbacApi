﻿using JalbacApi.Models;

namespace JalbacApi.Repositorio.IRepositorio
{
    public interface IEstadoRepositorio : IRepositorio<Estado>
    {
    }
}

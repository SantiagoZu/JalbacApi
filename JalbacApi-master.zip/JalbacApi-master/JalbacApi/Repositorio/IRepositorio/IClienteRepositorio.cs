﻿using JalbacApi.Models;

namespace JalbacApi.Repositorio.IRepositorio
{
    public interface IClienteRepositorio: IRepositorio<Cliente>
    {
    }
}

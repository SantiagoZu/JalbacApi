﻿using JalbacApi.Models;

namespace JalbacApi.Repositorio.IRepositorio
{
    public interface IEmpleadoRepositorio : IRepositorio<Empleado>
    {
    }
}

﻿

namespace JalbacApi.Models.Dto.EstadoDtos
{
    public class EstadoDto
    {
        public int IdEstado { get; set; }

        public string Nombre { get; set; } = null!;

        public string Descripcion { get; set; } = null!;
    }
}

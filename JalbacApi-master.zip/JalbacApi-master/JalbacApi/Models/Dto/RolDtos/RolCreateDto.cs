﻿namespace JalbacApi.Models.Dto.RolDtos
{
    public class RolCreateDto
    {
        public string Nombre { get; set; }

    }
}

﻿namespace JalbacApi.Models.Dto.RolDtos
{
    public class RolUpdateDto
    {
        public int IdRol { get; set; }

        public string Nombre { get; set; }
    }
}
